import 'package:blog_calendar/screen/home_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:get_it/get_it.dart';
import 'database/drift_database.dart';
import 'model/schedule_repository.dart';

void main() {
  final LocalDatabase database = LocalDatabase();
  GetIt.I.registerSingleton<LocalDatabase>(database);
  //------------------------------
  final repository = ScheduleRepository();
  GetIt.I.registerSingleton<ScheduleRepository>(repository);

  runApp(
      const MaterialApp(
          debugShowCheckedModeBanner: false,
          localizationsDelegates: [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
          ],
          supportedLocales: [
            const Locale('en'),
            const Locale('ko'),
          ],
          home: HomeScreen()
      )
  );
}
