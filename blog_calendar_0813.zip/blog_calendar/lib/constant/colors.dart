import 'package:flutter/material.dart';

const PRIMARY_COLOR  = Color(0xFF4374D9);
const GREEN_COLOR  = Color(0xFF22741C);
const MARK_COLOR  = Color(0xFF000000);
const GREY_COLOR  = Color(0xFFD5D5D5);
const RED_COLOR  = Color(0xFFFF0000);
const BLACK_COLOR  = Color(0xFF000000);

const titleStyle = TextStyle(
    fontWeight: FontWeight.w600,
    color: PRIMARY_COLOR
);
const textStyle = TextStyle(color: BLACK_COLOR);
final buttonStyle = ElevatedButton.styleFrom(backgroundColor: GREY_COLOR);
