import 'package:drift/drift.dart' hide Column;
import 'package:flutter/material.dart';
import 'package:get_it/get_it.dart';
import 'package:time_picker_sheet/widget/sheet.dart';
import 'package:time_picker_sheet/widget/time_picker.dart';
import '../constant/colors.dart';
import '../database/drift_database.dart';

class ScheduleBottomSheet extends StatefulWidget {
  const ScheduleBottomSheet({
    required this.schedule,
    Key? key}) : super(key: key);
  final Schedule schedule;

  @override
  State<ScheduleBottomSheet> createState() => _ScheduleBottomSheet();
}

class _ScheduleBottomSheet extends State<ScheduleBottomSheet> {
  late String currentDate;
  DateTime startTimeSelected = DateTime.now();
  DateTime endTimeSelected = DateTime.now();

  int? startTime;
  int? endTime;
  String? content;
//-------------------------------
  TextEditingController? controller;
  late final int id;

  @override
  void initState() {
    super.initState();
    currentDate = widget.schedule.date;
    int startHour = (widget.schedule.startTime ~/ 100);
    int startMin = (widget.schedule.startTime % 100);
    int endHour = (widget.schedule.endTime ~/ 100);
    int endMin = (widget.schedule.endTime % 100);
    startTimeSelected = DateTime(
        int.parse(currentDate.split('-')[0]),
        int.parse(currentDate.split('-')[1]),
        int.parse(currentDate.split('-')[2]),
        startHour, startMin, 0
    );
    endTimeSelected = DateTime(
        int.parse(currentDate.split('-')[0]),
        int.parse(currentDate.split('-')[1]),
        int.parse(currentDate.split('-')[2]),
        endHour, endMin, 0
    );
    //----------------------------------
    content = widget.schedule.content;
    controller = TextEditingController(text: content);

  }

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.of(context).viewInsets.bottom;
    Size size = MediaQuery.of(context).size;

    return Container(
        height: size.height / 2 + bottomInset,
        color: Colors.white,
        child: Padding(
          padding: EdgeInsets.only(left: 8, right: 8, top: 8, bottom: bottomInset),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              buildSelectDate(),
              Row(
                children: [
                  buildSelectTime(context, '시작시간', widget.schedule.startTime),
                  Spacer(),
                  buildSelectTime(context, '종료시간', widget.schedule.endTime),
                ]
              ),
              SizedBox(width: 16,),
              Text('내용', style: textStyle,),
              buildContent(),
              SizedBox(
                width: double.infinity,
                child: Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                          style: ElevatedButton.styleFrom(backgroundColor: PRIMARY_COLOR),
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                          child: Text('취소')
                      ),
                    ),
                    SizedBox(width: 10,),
                    Expanded(
                      child: ElevatedButton(
                          style: ElevatedButton.styleFrom(backgroundColor: PRIMARY_COLOR),
                          onPressed: () {
                            //----------------------
                            onSaveSchedule(widget.schedule.id);
                          },
                          child: Text('입력')
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        )
    );
  }

  Widget buildSelectDate() {
    return Row(
      children: [
        Text('날짜', style: titleStyle,),
        SizedBox(width: 8,),
        Expanded(
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: Colors.grey[300]),
            onPressed: () {
              selectDate(context);
            },
            child: Text(currentDate, style: textStyle)
          ),
        ),
      ]
    );
  }

  Future<void> selectDate(BuildContext context) async {
    DateTime convertDate = DateTime(
      int.parse(currentDate.split('-')[0]),
      int.parse(currentDate.split('-')[1]),
      int.parse(currentDate.split('-')[2]),
    );
    final DateTime? picked = await showDatePicker(
      context: context,
      locale: const Locale('ko', 'KR'),
      initialDate: convertDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2025),
    );
    if (picked != null && picked != convertDate) {
      setState(() {
        currentDate = picked.toString().split(' ')[0];
      });
    }
  }

  Widget buildSelectTime(BuildContext context, String label, int time) {
    Size size = MediaQuery.of(context).size;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: textStyle),
        SizedBox(
          width: size.width / 2.5,
          child: ElevatedButton(
            style: buttonStyle,
            onPressed: () {
              if (label == '시작시간') {
                openTimePickerSheet(context, true);
              } else {
                openTimePickerSheet(context, false);
              }
            },
            child: label=='시작시간'
                ? Text(
                '${startTimeSelected.hour.toString().padLeft(2, '0')}'
                    ':'
                    '${startTimeSelected.minute.toString().padLeft(2, '0')}',
                style: textStyle)
                : Text(
                '${endTimeSelected.hour.toString().padLeft(2, '0')}'
                    ':'
                    '${endTimeSelected.minute.toString().padLeft(2, '0')}',
                style: textStyle)
          ),
        ),
      ],
    );
  }

  void openTimePickerSheet(BuildContext context, bool isStart) async {
    final selectTime = await TimePicker.show<DateTime?>(
      context: context,
      sheet: TimePickerSheet(
        sheetTitle: '오늘의 일정',
        minuteTitle: '분',
        hourTitle: '시간',
        saveButtonText: '저장',
        initialDateTime: startTimeSelected,
        sheetCloseIconColor: Colors.black,
        wheelNumberSelectedStyle: TextStyle(fontSize: 20),
        saveButtonColor: Colors.green,
        sheetTitleStyle: TextStyle(color: Colors.blue, fontSize: 12),
        hourTitleStyle: TextStyle(color: Colors.blue, fontSize: 12),
        minuteTitleStyle: TextStyle(color: Colors.blue, fontSize: 12),
      ),
    );

    if (selectTime != null) {
      setState(() {
        if (isStart) {
          startTimeSelected = selectTime;
          endTimeSelected = selectTime;
        } else {
          if (selectTime.isAfter(startTimeSelected)) {
            endTimeSelected = selectTime;
          } else {
            endTimeSelected = selectTime;
          }
        }
      });
    }
  }

  Widget buildContent() {
    return Expanded(
      flex: 1,
      child: TextFormField(
        //-----------------
        controller: controller,
        expands: true,
        maxLines: null,
        keyboardType: TextInputType.multiline,
        onChanged: (String? val) {
          setState(() {
            content = val;
          });
        },
        decoration: InputDecoration(
          border: InputBorder.none,
          filled: true,
          fillColor: Colors.grey[300],
        ),
      ),
    );
  }

  void onSaveSchedule(int id) {
    if (content==null || content!.isEmpty) return;

    startTime = startTimeSelected.hour * 100 + startTimeSelected.minute;
    endTime = endTimeSelected.hour * 100 + endTimeSelected.minute;

    id==0
        ? GetIt.I<LocalDatabase>().createSchedule(
        SchedulesCompanion(
          startTime: Value(startTime!),
          endTime: Value(endTime!),
          content: Value(content!),
          date: Value(currentDate),
        )
    )
        : GetIt.I<LocalDatabase>().updateSchedule(
      Schedule(
        id: id,
        startTime: startTime!,
        endTime: endTime!,
        content: content!,
        date: currentDate,
      ),
    );

    Navigator.of(context).pop();
  }
}
